/* ========================
   BEUSHAREBOX - VANILLA JAVASCRIPT
   ======================== */

// Global products array
let products = [];

// DOM Elements
const productForm = document.getElementById('productForm');
const productsContainer = document.getElementById('productsContainer');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const totalProductsEl = document.getElementById('totalProducts');
const totalLikesEl = document.getElementById('totalLikes');

/* ========================
   INITIALIZATION
   ======================== */
document.addEventListener('DOMContentLoaded', () => {
    loadProductsFromLocalStorage();
    renderProducts();
    updateStats();
    attachEventListeners();
});

/* ========================
   EVENT LISTENERS
   ======================== */
function attachEventListeners() {
    // Form submission
    productForm.addEventListener('submit', handleAddProduct);
    
    // Search input
    searchInput.addEventListener('input', handleSearch);
    
    // Category filter
    categoryFilter.addEventListener('change', handleFilter);
}

/* ========================
   ADD PRODUCT
   ======================== */
function handleAddProduct(e) {
    e.preventDefault();
    
    // Get form values
    const title = document.getElementById('productTitle').value.trim();
    const description = document.getElementById('productDescription').value.trim();
    const price = parseFloat(document.getElementById('productPrice').value);
    const category = document.getElementById('productCategory').value;
    
    // Validate inputs
    if (!title || !description || !price || !category) {
        alert('Please fill in all fields correctly.');
        return;
    }
    
    if (price < 0) {
        alert('Price cannot be negative.');
        return;
    }
    
    // Create new product object
    const newProduct = {
        id: generateUniqueId(),
        title: title,
        description: description,
        price: price,
        category: category,
        likes: 0,
        comments: [],
        createdAt: new Date().toISOString()
    };
    
    // Add to products array
    products.unshift(newProduct); // Add to beginning
    
    // Save to localStorage
    saveProductsToLocalStorage();
    
    // Reset form
    productForm.reset();
    
    // Re-render products
    renderProducts();
    updateStats();
}

/* ========================
   RENDER PRODUCTS
   ======================== */
function renderProducts(productsToRender = products) {
    // Clear container
    productsContainer.innerHTML = '';
    
    // Show empty state if no products
    if (productsToRender.length === 0) {
        productsContainer.innerHTML = `
            <div class="empty-state">
                <h3>📦 No products found</h3>
                <p>Be the first to share a product!</p>
            </div>
        `;
        return;
    }
    
    // Render each product
    productsToRender.forEach(product => {
        const productCard = createProductCard(product);
        productsContainer.appendChild(productCard);
    });
}

/* ========================
   CREATE PRODUCT CARD
   ======================== */
function createProductCard(product) {
    const article = document.createElement('article');
    article.className = 'product-card';
    article.setAttribute('data-id', product.id);
    
    // Format date
    const date = new Date(product.createdAt);
    const formattedDate = date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
    
    // Create card HTML
    article.innerHTML = `
        <div class="product-header">
            <h3 class="product-title">${escapeHtml(product.title)}</h3>
            <span class="product-category">${escapeHtml(product.category)}</span>
        </div>
        
        <div class="product-body">
            <p class="product-description">${escapeHtml(product.description)}</p>
            <div class="product-price">$${product.price.toFixed(2)}</div>
            <div class="product-meta">Posted on ${formattedDate}</div>
        </div>
        
        <div class="product-actions">
            <button class="like-btn" onclick="handleLike('${product.id}')">
                ❤️ <span>${product.likes}</span>
            </button>
            <button class="btn btn-danger delete-btn" onclick="handleDelete('${product.id}')">
                Delete
            </button>
        </div>
        
        <div class="comments-section">
            <div class="comments-header">
                <h4>💬 Comments (${product.comments.length})</h4>
                <button class="toggle-comments" onclick="toggleComments('${product.id}')">
                    Show/Hide
                </button>
            </div>
            
            <div class="comment-form">
                <input 
                    type="text" 
                    class="comment-input" 
                    placeholder="Add a comment..."
                    id="comment-input-${product.id}"
                    maxlength="200"
                >
                <button class="add-comment-btn" onclick="handleAddComment('${product.id}')">
                    Post
                </button>
            </div>
            
            <div class="comments-list" id="comments-${product.id}">
                ${renderComments(product.comments)}
            </div>
        </div>
    `;
    
    return article;
}

/* ========================
   RENDER COMMENTS
   ======================== */
function renderComments(comments) {
    if (comments.length === 0) {
        return '<p style="color: #6b7280; font-size: 0.9rem; text-align: center; padding: 1rem;">No comments yet</p>';
    }
    
    return comments.map(comment => {
        const commentDate = new Date(comment.createdAt);
        const formattedDate = commentDate.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        return `
            <div class="comment-item">
                <p class="comment-text">${escapeHtml(comment.text)}</p>
                <span class="comment-date">${formattedDate}</span>
            </div>
        `;
    }).join('');
}

/* ========================
   LIKE PRODUCT
   ======================== */
function handleLike(productId) {
    const product = products.find(p => p.id === productId);
    
    if (product) {
        // Increment likes
        product.likes++;
        
        // Save to localStorage
        saveProductsToLocalStorage();
        
        // Re-render products
        renderProducts(getFilteredProducts());
        updateStats();
    }
}

/* ========================
   DELETE PRODUCT
   ======================== */
function handleDelete(productId) {
    // Show confirmation dialog
    const confirmed = confirm('Are you sure you want to delete this product?');
    
    if (confirmed) {
        // Remove product from array
        products = products.filter(p => p.id !== productId);
        
        // Save to localStorage
        saveProductsToLocalStorage();
        
        // Re-render products
        renderProducts(getFilteredProducts());
        updateStats();
    }
}

/* ========================
   ADD COMMENT
   ======================== */
function handleAddComment(productId) {
    const commentInput = document.getElementById(`comment-input-${productId}`);
    const commentText = commentInput.value.trim();
    
    if (!commentText) {
        alert('Please enter a comment.');
        return;
    }
    
    const product = products.find(p => p.id === productId);
    
    if (product) {
        // Create new comment object
        const newComment = {
            id: generateUniqueId(),
            text: commentText,
            createdAt: new Date().toISOString()
        };
        
        // Add comment to product
        product.comments.push(newComment);
        
        // Save to localStorage
        saveProductsToLocalStorage();
        
        // Clear input
        commentInput.value = '';
        
        // Re-render products
        renderProducts(getFilteredProducts());
        updateStats();
    }
}

/* ========================
   TOGGLE COMMENTS
   ======================== */
function toggleComments(productId) {
    const commentsList = document.getElementById(`comments-${productId}`);
    commentsList.classList.toggle('hidden');
}

/* ========================
   SEARCH FUNCTIONALITY
   ======================== */
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const filteredProducts = getFilteredProducts(searchTerm);
    renderProducts(filteredProducts);
}

/* ========================
   CATEGORY FILTER
   ======================== */
function handleFilter(e) {
    const filteredProducts = getFilteredProducts();
    renderProducts(filteredProducts);
}

/* ========================
   GET FILTERED PRODUCTS
   ======================== */
function getFilteredProducts(searchTerm = searchInput.value.toLowerCase()) {
    const selectedCategory = categoryFilter.value;
    
    let filtered = products;
    
    // Filter by category
    if (selectedCategory !== 'all') {
        filtered = filtered.filter(product => product.category === selectedCategory);
    }
    
    // Filter by search term
    if (searchTerm) {
        filtered = filtered.filter(product => {
            return product.title.toLowerCase().includes(searchTerm) ||
                   product.description.toLowerCase().includes(searchTerm) ||
                   product.category.toLowerCase().includes(searchTerm);
        });
    }
    
    return filtered;
}

/* ========================
   UPDATE STATISTICS
   ======================== */
function updateStats() {
    // Total products count
    totalProductsEl.textContent = products.length;
    
    // Total likes count
    const totalLikes = products.reduce((sum, product) => sum + product.likes, 0);
    totalLikesEl.textContent = totalLikes;
}

/* ========================
   LOCALSTORAGE FUNCTIONS
   ======================== */
function saveProductsToLocalStorage() {
    try {
        localStorage.setItem('beuShareBoxProducts', JSON.stringify(products));
    } catch (error) {
        console.error('Error saving to localStorage:', error);
    }
}

function loadProductsFromLocalStorage() {
    try {
        const storedProducts = localStorage.getItem('beuShareBoxProducts');
        if (storedProducts) {
            products = JSON.parse(storedProducts);
        }
    } catch (error) {
        console.error('Error loading from localStorage:', error);
        products = [];
    }
}

/* ========================
   UTILITY FUNCTIONS
   ======================== */
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

/* ========================
   DEMO DATA (Optional)
   ======================== */
// Uncomment the function below to add demo products on first load
/*
function addDemoData() {
    if (products.length === 0) {
        const demoProducts = [
            {
                id: generateUniqueId(),
                title: 'Wireless Headphones',
                description: 'High-quality bluetooth headphones with noise cancellation',
                price: 89.99,
                category: 'electronics',
                likes: 5,
                comments: [
                    {
                        id: generateUniqueId(),
                        text: 'Great product!',
                        createdAt: new Date().toISOString()
                    }
                ],
                createdAt: new Date().toISOString()
            },
            {
                id: generateUniqueId(),
                title: 'Running Shoes',
                description: 'Comfortable running shoes for daily exercise',
                price: 59.99,
                category: 'sports',
                likes: 3,
                comments: [],
                createdAt: new Date().toISOString()
            }
        ];
        
        products = demoProducts;
        saveProductsToLocalStorage();
    }
}
// Call this in DOMContentLoaded: addDemoData();
*/
